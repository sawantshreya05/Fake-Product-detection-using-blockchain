package com.baecon.scan;

public class UrlLinks {

    public static String urlserverpython="http://192.168.0.104:5000/";
    public static String pyregister=urlserverpython+"scan";

}
